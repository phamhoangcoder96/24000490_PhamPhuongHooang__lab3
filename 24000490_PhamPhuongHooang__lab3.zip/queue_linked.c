/*
  queue_linked.c
  Dynamic queue (singly-linked list) for ints.
  Implements: init, isEmpty, enqueue, dequeue, peek, clear.
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct NodeQ {
    int data;
    struct NodeQ *next;
} NodeQ;

typedef struct Queue {
    NodeQ *front, *rear;
} Queue;

void initQueue(Queue *q) { q->front = q->rear = NULL; }

bool isEmptyQ(Queue *q) { return q->front == NULL; }

void enqueue(Queue *q, int val) {
    NodeQ *n = malloc(sizeof(NodeQ));
    if (!n) { perror("malloc"); exit(EXIT_FAILURE); }
    n->data = val; n->next = NULL;
    if (isEmptyQ(q)) q->front = q->rear = n;
    else { q->rear->next = n; q->rear = n; }
}

int dequeue(Queue *q) {
    if (isEmptyQ(q)) { fprintf(stderr, "dequeue from empty queue\\n"); exit(EXIT_FAILURE); }
    NodeQ *t = q->front; int v = t->data; q->front = t->next;
    if (q->front == NULL) q->rear = NULL;
    free(t); return v;
}

int peekQ(Queue *q) {
    if (isEmptyQ(q)) { fprintf(stderr, "peek from empty queue\\n"); exit(EXIT_FAILURE); }
    return q->front->data;
}

void clearQueue(Queue *q) {
    while (!isEmptyQ(q)) dequeue(q);
}

/* Simple demo (compile with -DDEMO_QUEUE_LINKED to test) */
#ifdef DEMO_QUEUE_LINKED
int main(void) {
    Queue q; initQueue(&q);
    enqueue(&q, 10); enqueue(&q, 20); enqueue(&q, 30);
    printf("%d\\n", dequeue(&q));
    printf("%d\\n", peekQ(&q));
    clearQueue(&q);
    return 0;
}
#endif
