/*
  stack_linked.c
  Dynamic stack (singly-linked list) for ints.
  Implements: init, isEmpty, push, pop, peek, clear.
  Also includes an example: decimal -> binary conversion.
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct Stack {
    Node *top;
} Stack;

void initStack(Stack *s) { s->top = NULL; }

bool isEmpty(Stack *s) { return s->top == NULL; }

void push(Stack *s, int val) {
    Node *n = malloc(sizeof(Node));
    if (!n) { perror("malloc"); exit(EXIT_FAILURE); }
    n->data = val; n->next = s->top; s->top = n;
}

int pop(Stack *s) {
    if (isEmpty(s)) { fprintf(stderr, "pop from empty stack\\n"); exit(EXIT_FAILURE); }
    Node *t = s->top; int v = t->data; s->top = t->next; free(t); return v;
}

int peek(Stack *s) {
    if (isEmpty(s)) { fprintf(stderr, "peek from empty stack\\n"); exit(EXIT_FAILURE); }
    return s->top->data;
}

void clearStack(Stack *s) {
    while (!isEmpty(s)) pop(s);
}

/* Convert unsigned decimal to binary using the stack above */
void decToBinary(unsigned int n) {
    Stack st; initStack(&st);
    if (n == 0) { printf("0\\n"); return; }
    while (n) { push(&st, n & 1); n >>= 1; }
    while (!isEmpty(&st)) printf("%d", pop(&st));
    printf("\\n");
}

/* Simple interactive demo when run directly */
#ifdef DEMO_STACK_LINKED
int main(void) {
    unsigned int x;
    printf("Enter non-negative integer: ");
    if (scanf("%u", &x) != 1) return 0;
    printf("Binary: "); decToBinary(x);
    return 0;
}
#endif
