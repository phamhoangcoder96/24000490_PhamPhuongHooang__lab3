/*
  array_stack_commands.c
  Array-based stack with MAX capacity and command parsing.
  Supported commands (case-sensitive):
    PUSH x   -- push integer x
    POP      -- pop top (no output)
    TOP      -- print top element or "EMPTY"
    SIZE     -- print current size
    END      -- terminate
  Prints "FULL" or "EMPTY" on overflow/underflow as noted in assignment.
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX 100

static int st[MAX];
static int top = -1;

static inline int isEmpty(void) { return top == -1; }
static inline int isFull(void) { return top == MAX - 1; }

void push_val(int x) {
    if (isFull()) { puts("FULL"); return; }
    st[++top] = x;
}

void pop_cmd(void) {
    if (isEmpty()) { puts("EMPTY"); return; }
    --top;
}

void top_cmd(void) {
    if (isEmpty()) { puts("EMPTY"); return; }
    printf("%d\n", st[top]);
}

void size_cmd(void) {
    printf("%d\n", top + 1);
}

int main(void) {
    char line[128];
    while (fgets(line, sizeof(line), stdin)) {
        // trim newline
        line[strcspn(line, "\r\n")] = 0;
        if (strncmp(line, "PUSH", 4) == 0) {
            // allow "PUSH   -10" etc.
            char *p = line + 4;
            while (isspace((unsigned char)*p)) ++p;
            char *endptr;
            long v = strtol(p, &endptr, 10);
            if (p == endptr) continue; // no number found
            push_val((int)v);
        } else if (strcmp(line, "POP") == 0) {
            pop_cmd();
        } else if (strcmp(line, "TOP") == 0) {
            top_cmd();
        } else if (strcmp(line, "SIZE") == 0) {
            size_cmd();
        } else if (strcmp(line, "END") == 0) {
            break;
        }
    }
    return 0;
}
