/*
  infix_postfix_eval.c
  Convert infix expression (integers and operators + - * / ^, parentheses)
  to postfix using the Shunting-yard algorithm and then evaluate the postfix.
  Prints:
    - first line: postfix tokens separated by single spaces
    - second line: integer result (long long)
  Notes:
    - ^ is right-associative
    - integer division with truncation toward zero (C behavior)
    - handles multi-digit integers and unary minus for negative literals (simple handling)
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    if (op == '^') return 3;
    return 0;
}
int is_right_assoc(char op) { return op == '^'; }

void infix_to_postfix(const char *in, char *out) {
    char ops[1024]; int top = -1;
    int i = 0, L = strlen(in);
    out[0] = 0;
    while (i < L) {
        if (isspace((unsigned char)in[i])) { ++i; continue; }
        if (isdigit((unsigned char)in[i]) || 
            (in[i] == '-' && (i == 0 || in[i-1] == '(' || strchr("+-*/^", in[i-1]) != NULL) && isdigit((unsigned char)in[i+1]))) {
            /* number or unary negative literal */
            int j = i;
            if (in[i] == '-') ++j; /* include sign */
            while (j < L && isdigit((unsigned char)in[j])) ++j;
            strncat(out, in + i, j - i);
            strcat(out, " ");
            i = j;
        } else if (in[i] == '(') {
            ops[++top] = '('; ++i;
        } else if (in[i] == ')') {
            while (top >= 0 && ops[top] != '(') { char t[2] = {ops[top--], 0}; strcat(out, t); strcat(out, " "); }
            if (top >= 0 && ops[top] == '(') --top;
            ++i;
        } else {
            char op = in[i++];
            while (top >= 0 && ops[top] != '(') {
                int ptop = precedence(ops[top]);
                int pop  = precedence(op);
                if ( (ptop > pop) || (ptop == pop && !is_right_assoc(op)) ) {
                    char t[2] = {ops[top--], 0};
                    strcat(out, t); strcat(out, " ");
                } else break;
            }
            ops[++top] = op;
        }
    }
    while (top >= 0) { char t[2] = {ops[top--], 0}; strcat(out, t); strcat(out, " "); }
    int len = strlen(out); if (len && out[len-1] == ' ') out[len-1] = 0;
}

long long eval_postfix(const char *post) {
    long long st[2048]; int top = -1;
    char *buf = strdup(post);
    char *tok = strtok(buf, " ");
    while (tok) {
        if (tok[0] == '+' || tok[0] == '-' || tok[0] == '*' || tok[0] == '/' || tok[0] == '^') {
            if (top < 1) { free(buf); fprintf(stderr,"Invalid postfix\\n"); exit(EXIT_FAILURE); }
            long long b = st[top--]; long long a = st[top--]; long long r = 0;
            switch (tok[0]) {
                case '+': r = a + b; break;
                case '-': r = a - b; break;
                case '*': r = a * b; break;
                case '/': r = a / b; break;
                case '^': {
                    long long res = 1;
                    int times = (int)b;
                    if (times < 0) { fprintf(stderr, "Negative exponent not supported\\n"); free(buf); exit(EXIT_FAILURE); }
                    while (times--) res *= a;
                    r = res;
                    break;
                }
            }
            st[++top] = r;
        } else {
            st[++top] = atoll(tok);
        }
        tok = strtok(NULL, " ");
    }
    long long ans = (top == 0) ? st[top] : 0;
    free(buf);
    return ans;
}

int main(void) {
    char line[4096];
    if (!fgets(line, sizeof(line), stdin)) return 0;
    line[strcspn(line, "\r\n")] = 0;
    char postfix[8192] = {0};
    infix_to_postfix(line, postfix);
    printf("%s\n", postfix);
    long long val = eval_postfix(postfix);
    printf("%lld\n", val);
    return 0;
}
