/*
  brackets_and_tags.c
  Part A: Validate bracket sequences of ()[]{}  -> prints YES/NO per input line.
  Part B: Validate simple HTML-like tags <tag>...</tag> (lowercase letters only) -> prints YES/NO.
  This program reads lines; to check tags prefix the line with "TAG:" (without quotes),
  otherwise it treats the line as bracket-checking input. This keeps both parts in one file.
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define STACK_CAP 10000

/* Part A: brackets */
int is_matching(char open, char close) {
    return (open == '(' && close == ')') ||
           (open == '[' && close == ']') ||
           (open == '{' && close == '}');
}

int check_brackets(const char *s) {
    char stack[STACK_CAP];
    int top = -1;
    for (const char *p = s; *p; ++p) {
        if (*p == '(' || *p == '[' || *p == '{') {
            if (top + 1 >= STACK_CAP) return 0;
            stack[++top] = *p;
        } else if (*p == ')' || *p == ']' || *p == '}') {
            if (top < 0) return 0;
            if (!is_matching(stack[top--], *p)) return 0;
        }
    }
    return top == -1;
}

/* Part B: simple tag checker */
int is_lower_alpha_str(const char *s, int len) {
    if (len <= 0) return 0;
    for (int i = 0; i < len; ++i) if (!(s[i] >= 'a' && s[i] <= 'z')) return 0;
    return 1;
}

int check_tags(const char *s) {
    /* stack of tag names (pointers to small buffer) */
    const int MAXT = 1000;
    char stack[MAXT][128];
    int top = -1;
    int n = strlen(s);
    for (int i = 0; i < n; ) {
        if (s[i] == '<') {
            if (i + 1 < n && s[i+1] == '/') {
                /* closing tag */
                i += 2;
                int j = 0;
                while (i < n && s[i] != '>' && j < 127) stack[(top>=0)?top+1:0][j++] = s[i++];
                int start = i - j;
                if (i >= n || s[i] != '>') return 0;
                if (j >= 128) return 0;
                char name[128]; memcpy(name, &s[start], j); name[j] = 0;
                if (!is_lower_alpha_str(name, j)) return 0;
                if (top < 0) return 0;
                if (strcmp(name, stack[top]) != 0) return 0;
                --top;
                ++i;
            } else {
                /* opening tag */
                ++i;
                int j = 0;
                int start = i;
                while (i < n && s[i] != '>' && j < 127) ++i, ++j;
                if (i >= n || s[i] != '>') return 0;
                char name[128];
                int len = j;
                if (len >= 128) return 0;
                memcpy(name, &s[start], len); name[len] = 0;
                if (!is_lower_alpha_str(name, len)) return 0;
                if (top + 1 >= MAXT) return 0;
                strcpy(stack[++top], name);
                ++i;
            }
        } else {
            ++i;
        }
    }
    return top == -1;
}

/* Main: if a line begins with "TAG:" we perform tag-check; otherwise bracket-check */
int main(void) {
    char line[5000];
    while (fgets(line, sizeof(line), stdin)) {
        // trim newline
        line[strcspn(line, "\r\n")] = 0;
        if (strncmp(line, "TAG:", 4) == 0) {
            const char *payload = line + 4;
            puts(check_tags(payload) ? "YES" : "NO");
        } else {
            puts(check_brackets(line) ? "YES" : "NO");
        }
    }
    return 0;
}
